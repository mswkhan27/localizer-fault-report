from src.localizer import Localizer
from src.localizer import run_localizer

if __name__ == "__main__":
    localizer_configs = [
        {"project_path": "examples/multiply/", "file_n": "multiply.py", "test_file": "examples/multiply/tests/tests.txt", "outputFile": 'fault_summary.json', "debug": True, "entry_point": "multiply", "metric": 'savg'},
        {"project_path": "examples/power/", "file_n": "power.py", "test_file": "examples/power/tests/tests.txt", "outputFile": 'fault_summary.json', "debug": True, "entry_point": "power"},
        {"project_path": "examples/circles_overlap/", "file_n": "circles_overlap.py", "test_file": "examples/circles_overlap/tests/tests.txt", "outputFile": 'fault_summary.json', "debug": True, "entry_point": "circle_overlap_status"},
        {"project_path": "examples/hex_conversion/", "file_n": "hex_conversion.py", "test_file": "examples/hex_conversion/tests/tests.txt", "outputFile": 'fault_summary.json', "debug": True, "entry_point": "hex_conversion", "metric": 'savg'},
        {"project_path": "examples/next_day/", "file_n": "next_day.py", "test_file": "examples/next_day/tests/tests.txt", "outputFile": 'fault_summary.json', "debug": True, "entry_point": "get_next_date"},
        {"project_path": "examples/next_palindrome/", "file_n": "next_palindrome.py", "test_file": "examples/next_palindrome/tests/tests.txt", "outputFile": 'fault_summary.json', "debug": True, "entry_point": "next_palindrome"},
        {"project_path": "examples/progression/", "file_n": "progression.py", "test_file": "examples/progression/tests/tests.txt", "outputFile": 'fault_summary.json', "debug": True, "entry_point": "ap_gp_sequence"},
        {"project_path": "examples/trityp/", "file_n": "trityp.py", "test_file": "examples/trityp/tests/tests.txt", "outputFile": 'fault_summary.json', "debug": True, "entry_point": "trityp"},
        {"project_path": "examples/mergesort/", "file_n": "mergesort.py", "test_file": "examples/mergesort/tests/tests.txt", "outputFile": 'fault_summary.json', "debug": True, "entry_point": "mergesort"},
        {"project_path": "examples/equilateral_area/", "file_n": "equilateral_area.py", "test_file": "examples/equilateral_area/tests/tests.txt", "outputFile": 'fault_summary.json', "debug": True, "entry_point": "equilateral_area"}
]

    for config in localizer_configs:
        loc = Localizer(**config)
        run_localizer(loc)
