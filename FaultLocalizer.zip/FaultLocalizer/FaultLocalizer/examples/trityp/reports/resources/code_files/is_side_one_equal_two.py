def is_side_one_equal_two(type_code):
    c[20] += 1
    if type_code >= 0:
        c[3] += 1
        type_code = type_code + 1
        return type_code
